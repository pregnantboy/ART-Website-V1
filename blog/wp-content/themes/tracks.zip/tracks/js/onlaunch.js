(function($) {
	$(document).ready(function() {
		$('.navbar-default').css({'display':'block'});	
		setTimeout(function(){ 	
			$('.navbar-default').css({'opacity':1});
		},0);
	});

})(jQuery);