<div class='entry entry-bbpress'>
	<div class='entry-header'>
		<h1 class='entry-title'><?php the_title(); ?></h1>
	</div>
	<div class="entry-container">
		<div class='entry-content'>
			<article>
				<?php the_content(); ?>
			</article>
		</div>
	</div>
</div>