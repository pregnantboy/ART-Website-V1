<nav class="further-reading">
	<div class="previous">
		<span><?php previous_image_link( false, __( 'Previous Image', 'founder' ) ); ?></span>
	</div>
	<div class="next">
		<span><?php next_image_link( false, __( 'Next Image', 'founder' ) ); ?></span>
	</div>
</nav>